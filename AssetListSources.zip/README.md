This is a solution for the task defined in Frontend_Case_Study.pdf document

To run locally, install yarn, then type 
`yarn`
wait for install, then type
`yarn develop`
then open site on http://localhost:8000/


Based on React, Material UI 5, Gatsby, Fixer Forex API.

